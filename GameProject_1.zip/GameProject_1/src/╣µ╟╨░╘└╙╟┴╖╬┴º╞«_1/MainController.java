package 방학게임프로젝트_1;

public class MainController {
	public static void main(String[] args) {
		MainFrame mainFrame = new MainFrame();
		mainFrame.mainFrame();
	}
}
